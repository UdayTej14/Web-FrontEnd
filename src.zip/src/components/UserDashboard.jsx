import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const UserDashboard = () => {
  const [user, setUser] = useState(null);
  const [recipes, setRecipes] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [newRecipe, setNewRecipe] = useState({
    title: '',
    description: '',
    ingredients: [{ name: '', quantity: '', measurementUnit: '' }],
    instructions: [''],
    cookingTime: '',
    prepTime: '',
    servings: '',
    imageURL: '',
    categories: [],
  });
  const navigate = useNavigate();

  const categoriesOptions = ['Chinese', 'Indian', 'Italian', 'Thai', 'Mexican', 'Japanese'];

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const response = await axios.get('/api/users/me', { withCredentials: true });
        setUser(response.data);
        setRecipes(response.data.recipes || []);
      } catch (error) {
        console.error('Error fetching user data:', error);
        navigate('/login'); // Redirect to login if fetching user data fails
      }
    };

    fetchUserData();
  }, [navigate]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setNewRecipe((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleCategoryChange = (e) => {
    setNewRecipe((prev) => ({
      ...prev,
      categories: [e.target.value],
    }));
  };

  const handleIngredientChange = (index, field, value) => {
    const updatedIngredients = [...newRecipe.ingredients];
    updatedIngredients[index][field] = value;
    setNewRecipe((prev) => ({
      ...prev,
      ingredients: updatedIngredients,
    }));
  };

  const addIngredientField = () => {
    setNewRecipe((prev) => ({
      ...prev,
      ingredients: [...prev.ingredients, { name: '', quantity: '', measurementUnit: '' }],
    }));
  };

  const handleSubmit = async () => {
    try {
      const response = await axios.post('/api/recipes/add', newRecipe, { withCredentials: true });
      alert('Recipe added successfully');
      setRecipes((prev) => [...prev, response.data.recipe]);
      setShowModal(false);
    } catch (error) {
      console.error('Error adding recipe:', error);
    }
  };

  if (!user) {
    return null; // Show nothing while user data is being fetched
  }

  return (
    <div className="dashboard-container p-6 pt-20">
      <div className="profile-section text-center mb-6">
        <img
          src={user?.profilePicture || '/default-profile.png'}
          alt="Profile"
          className="w-20 h-20 rounded-full mx-auto mb-4"
        />
        <h2 className="text-2xl font-bold">{user?.name}</h2>
      </div>

      <div className="recipes-section">
        <button
          onClick={() => setShowModal(true)}
          className="bg-blue-500 text-white px-4 py-2 rounded-md"
        >
          Add New Recipe
        </button>

        <div className="recipes-list mt-6">
          {recipes.map((recipe) => (
            <div key={recipe._id} className="recipe-card mb-4 border p-4">
              <h3 className="text-xl font-bold">{recipe.title}</h3>
              <p>{recipe.description}</p>
              <button
                onClick={() => navigate(`/recipe/${recipe._id}`)}
                className="text-blue-500 hover:underline"
              >
                View Details
              </button>
            </div>
          ))}
        </div>
      </div>

      {showModal && (
        <div className="modal fixed inset-0 bg-gray-900 bg-opacity-90 flex justify-center items-center overflow-auto z-50">
          <div className="modal-content bg-gray-800 p-6 rounded-lg shadow-lg w-96 relative">
            <button
              onClick={() => setShowModal(false)}
              className="absolute top-2 right-2 text-gray-400 hover:text-gray-200"
            >
              X
            </button>

            <h2 className="text-xl font-bold mb-4 text-white">Add New Recipe</h2>
            <div>
              <label className="text-gray-300">Title</label>
              <input
                type="text"
                name="title"
                value={newRecipe.title}
                onChange={handleChange}
                className="w-full mb-4 p-2 border bg-gray-700 text-white"
              />
            </div>

            <div>
              <label className="text-gray-300">Description</label>
              <textarea
                name="description"
                value={newRecipe.description}
                onChange={handleChange}
                className="w-full mb-4 p-2 border bg-gray-700 text-white"
              ></textarea>
            </div>

            <div>
              <label className="text-gray-300">Category</label>
              <select
                name="category"
                value={newRecipe.categories[0] || ''}
                onChange={handleCategoryChange}
                className="w-full mb-4 p-2 border bg-gray-700 text-white"
              >
                <option value="" disabled>
                  Select a category
                </option>
                {categoriesOptions.map((category) => (
                  <option key={category} value={category}>
                    {category}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-gray-300">Image URL</label>
              <input
                type="url"
                name="imageURL"
                value={newRecipe.imageURL}
                onChange={handleChange}
                className="w-full mb-4 p-2 border bg-gray-700 text-white"
                placeholder="Paste image URL here"
              />
            </div>

            <div className="overflow-y-auto h-40"> {/* Scrollable container for ingredients */}
              <h3 className="text-gray-300">Ingredients</h3>
              {newRecipe.ingredients.map((ingredient, index) => (
                <div key={index} className="mb-4">
                  <input
                    type="text"
                    placeholder="Name"
                    value={ingredient.name}
                    onChange={(e) => handleIngredientChange(index, 'name', e.target.value)}
                    className="w-full mb-2 p-2 border bg-gray-700 text-white"
                  />
                  <input
                    type="number"
                    placeholder="Quantity"
                    value={ingredient.quantity}
                    onChange={(e) => handleIngredientChange(index, 'quantity', e.target.value)}
                    className="w-full mb-2 p-2 border bg-gray-700 text-white"
                  />
                  <input
                    type="text"
                    placeholder="Measurement Unit"
                    value={ingredient.measurementUnit}
                    onChange={(e) => handleIngredientChange(index, 'measurementUnit', e.target.value)}
                    className="w-full mb-2 p-2 border bg-gray-700 text-white"
                  />
                </div>
              ))}
              <button
                onClick={addIngredientField}
                className="bg-gray-600 text-gray-300 px-2 py-1 rounded hover:bg-gray-500"
              >
                + Add Ingredient
              </button>
            </div>

            <button
              onClick={handleSubmit}
              className="bg-blue-500 text-white px-4 py-2 rounded-md mt-4 hover:bg-blue-600"
            >
              Add Recipe
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default UserDashboard;
